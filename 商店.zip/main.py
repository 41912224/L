from LoginPage import *


root = Tk()
root.title('商店')
LoginPage(root)
root.mainloop()
